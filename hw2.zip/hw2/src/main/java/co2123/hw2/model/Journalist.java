package co2123.hw2.model;

import java.util.List;

public class Journalist {
    private String speciality;
    private List<Newspaper> newspapers;
    private List <Article> articles;
    private Article popular;

    public String getSpeciality() {
        return speciality;
    }

    public void setSpeciality(String speciality) {
        this.speciality = speciality;
    }

    public List<Newspaper> getNewspapers() {
        return newspapers;
    }

    public void setNewspapers(List<Newspaper> newspapers) {
        this.newspapers = newspapers;
    }

    public List<Article> getArticles() {
        return articles;
    }

    public void setArticles(List<Article> articles) {
        this.articles = articles;
    }

    public Article getPopular() {
        return popular;
    }

    public void setPopular(Article popular) {
        this.popular = popular;
    }

    @Override
    public String toString() {
        return "Journalist{" +
                "popular=" + popular +
                ", articles=" + articles +
                ", speciality='" + speciality + '\'' +
                '}';
    }
}
